UA Token — Докази для CoinMarketCap
    
1. Raydium UA/SOL liquidity:
   https://raydium.io/swap/?inputMint=So11111111111111111111111111111111111111112&outputMint=AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH

2. Jupiter UA token page:
   https://jup.ag/tokens/AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH

3. Twitter official:
   https://x.com/volya089

4. Telegram official channel:
   https://t.me/VolyaUkraineOfficial

5. Official website UA Token page:
   https://volya.io/ua-token

6. Solscan token page:
   https://solscan.io/token/AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH

---
Всі наведені посилання належать офіційно команді UA Token.
