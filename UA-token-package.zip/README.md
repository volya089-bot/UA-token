# UA Token

UA Token — офіційний токен у мережі Solana з фіксованою емісією 10,000,000 UA.

## Загальна інформація
- **Назва:** UA Token
- **Символ:** UA
- **Мережа:** Solana
- **Адреса смартконтракту (Mint):** AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH
- **Десяткові знаки:** 6
- **Максимальна емісія:** 10,000,000 UA

## Опис
UA Token створений для підтримки та розвитку українських криптопроєктів і комʼюніті. Токен використовується для торгівлі, дропів та внутрішніх сервісів платформи Volya.io.

## Офіційні посилання
- Website: https://volya.io
- Twitter: https://twitter.com/volya089
- Telegram: https://t.me/VolyaUkraineOfficial

---
© 2025 Volya.io
