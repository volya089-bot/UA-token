# UA Token (UA)

## Adoption & Proof

### 1. Raydium Liquidity Pool  
![UA/SOL Raydium Pool](proof/raydium_pool.png)  
[View on Raydium](https://raydium.io/swap/?inputCurrency=sol&outputCurrency=UA)

---

### 2. Jupiter Listing  
![UA Token on Jupiter](proof/jupiter_token.png)  
[View on Jupiter](https://jup.ag/tokens/AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH)

---

### 3. UA Drop Telegram Bot  
![UA Drop Bot](proof/telegram_airdrop_bot.png)  
[Join the Bot](https://t.me/UATokenDropBot)

---

### 4. Phantom Wallet  
![UA Balance in Phantom](proof/phantom_wallet.png)

---

### 5. Summary of Adoption  
- 150+ early supporters in Telegram  
- Active AMM pool on Raydium (UA/SOL)  
- Immutable smart contract: `AhpZHEopZpqLJ2XYgHfRr8dxhTLCHDTTDuw7dStyoawH`  
- Fixed total supply: **10,000,000 UA**  
- Integrated with Solana DEXs (Raydium, Jupiter, OpenBook)  
- Airdrop allocation: 2,500,000 UA  

---

📌 **Instructions for CMC Reviewers**  
All proofs are available in the `/proof` folder of this repository.  
